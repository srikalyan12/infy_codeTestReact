import React, { Component } from 'react';
import TextField from '@material-ui/core/TextField';  
import { withStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';

import moment from 'moment';

const styles = theme => ({
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
  },
  button: {
    margin: theme.spacing.unit,
  },
  main: {
    magin: 'auto'
  }
});

class App extends Component {

  constructor(props) {
    super(props);

    this.state = {
      date1: '',
      date2: '',
      diffDays: 0,
      errorDate1: false,
      errorDate2: false,

    };
    this.handleChange = this.handleChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }
  onSubmit() {
    let temp;
    const datearr1 = this.state.date1.split(' ');
      temp = datearr1[1];
      datearr1[1] = datearr1[0];
      datearr1[0] = temp;
    const datearr2 = this.state.date2.split(' ');
      temp = datearr2[1];
      datearr2[1] = datearr2[0];
      datearr2[0] = temp;
    const validDate1 = moment(datearr1.join(' ')).format('DD MM YYYY');
    const validDate2 = moment(datearr2.join(' ')).format('DD MM YYYY');

    let errorDate1 = false;
    let errorDate2 = false;
    if (validDate1 === 'Invalid date') {
      errorDate1 = true;
    }
    if (validDate2 === 'Invalid date') {
      errorDate2 = true;
    }
    if (!errorDate1 && !errorDate2) {
      const date1dif = moment(this.state.date1, 'DD MM YYYY');
      const date2dif = moment(this.state.date2, 'DD MM YYYY');
      const diffDays = date2dif.diff(date1dif, 'days');
      this.setState({
        diffDays
      });
    }
    this.setState({
      errorDate1, errorDate2
    });
  }
  handleChange(event) {
    if (event.target.id === 'date1') {
      this.setState({
        date1: event.target.value
      });
    } 
    else {
      this.setState({
        date2: event.target.value
      });
    }
  }
  render() {
    const { classes } = this.props;
    return (
      <div className={classes.main}>
      <form className={classes.container} noValidate autoComplete="off">
          <TextField
          error={this.state.errorDate1}
          required
          id="date1"
          label="DD MM YYYY"
          className={classes.textField}
          value={this.state.name}
          onChange={this.handleChange}
          margin="normal"
          variant="outlined"
          helperText="Some important text"
          helperText={this.state.errorDate1 ? 'Enter valid Date in DD MM YYY' : ''}
          />
          <TextField
            error={this.state.errorDate2}
            required
            id="date2"
            label="DD MM YYYY"
            className={classes.textField}
            onChange={this.handleChange}
            margin="normal"
            variant="outlined"
            helperText={this.state.errorDate2 ? "Enter valid Date in DD MM YYY": ""}
          />
      </form>

        <Button 
            size="small" 
            variant="contained" 
            color="primary"  
            className={classes.button} 
            onClick={this.onSubmit}
        >
          Find Date Difference
        </Button>

        <Button size="small" variant="contained" color="secondary" className={classes.button} >
         { `Date Difference: ${this.state.diffDays} days`}
        </Button>
    </div>
    );
  }
}
export default withStyles(styles)(App);
